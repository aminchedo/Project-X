# Security
- Use `npm audit` and `pip-audit` in CI.
- Do not commit secrets. Use GitHub Actions secrets.
- Rotate tokens regularly.